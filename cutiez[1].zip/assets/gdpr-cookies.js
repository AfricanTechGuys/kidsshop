function getBannerEl() {
    return document.getElementById('cookies-banner');
  }

  function hideBanner(res) {
    getBannerEl().style.display = 'none';
    console.log("hide-it");
  }

  function showBanner() {
   getBannerEl().style.display = 'flex';
    console.log("show-it");
  }

  function handleAccept(e) {
    window.Shopify.customerPrivacy.setTrackingConsent(true, hideBanner);
    document.addEventListener('trackingConsentAccepted',function() {
      console.log('trackingConsentAccepted event fired');      
    });
  }

  function handleDecline() {
    window.Shopify.customerPrivacy.setTrackingConsent(false,hideBanner);
  }

  function initCookieBanner() {
    const userCanBeTracked = window.Shopify.customerPrivacy.userCanBeTracked();
    const userTrackingConsent = window.Shopify.customerPrivacy.getTrackingConsent();
    if(!userCanBeTracked && userTrackingConsent === 'no_interaction') {
      showBanner();
    }    
  }

  window.Shopify.loadFeatures([
    {
      name: 'consent-tracking-api',
      version: '0.1',
    }
  ],
  function(error) {
    if (error) {
      throw error;
    }

    initCookieBanner();
});